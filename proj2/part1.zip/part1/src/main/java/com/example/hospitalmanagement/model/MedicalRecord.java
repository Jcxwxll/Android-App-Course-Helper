package com.example.hospitalmanagement.model;

import lombok.Data;
import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Data
@Entity
public class MedicalRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    private LocalDateTime recordDate;

    @NotBlank
    private String diagnosis;

    private String treatment;

    private String notes;

    // Each appointment has one medical record
    @OneToOne
    @JoinColumn(name = "appointment_id")
    private Appointment appointment;
}
