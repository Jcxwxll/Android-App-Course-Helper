package com.example.hospitalmanagement.service;

import com.example.hospitalmanagement.model.Doctor;
import com.example.hospitalmanagement.model.Appointment;
import com.example.hospitalmanagement.repository.DoctorRepository;
import com.example.hospitalmanagement.repository.AppointmentRepository;
import com.example.hospitalmanagement.repository.MedicalRecordRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class DoctorService {
    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private MedicalRecordRepository medicalRecordRepository;

    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }

    public Doctor createDoctor(Doctor doctor) {
        return doctorRepository.save(doctor);
    }

    public Doctor getDoctorById(Long id) {
        Optional<Doctor> opt = doctorRepository.findById(id);
        return opt.orElse(null);
    }

    public Doctor updateDoctor(Long id, Doctor doctorDetails) {
        return doctorRepository.findById(id).map(doctor -> {
            doctor.setName(doctorDetails.getName());
            doctor.setSpecialisation(doctorDetails.getSpecialisation());
            doctor.setEmail(doctorDetails.getEmail());
            doctor.setPhoneNumber(doctorDetails.getPhoneNumber());
            return doctorRepository.save(doctor);
        }).orElse(null);
    }

    public boolean deleteDoctor(Long id) {
        if (doctorRepository.existsById(id)) {
            // Retrieve all appointments for this doctor.
            List<Appointment> appointments = appointmentRepository.findByDoctorId(id);
            // For each appointment, detach the medical record reference so that it isn't cascade-deleted.
            for (Appointment appointment : appointments) {
                if (appointment.getMedicalRecord() != null) {
                    appointment.setMedicalRecord(null);
                    appointmentRepository.save(appointment);
                }
            }
            // Now, delete the doctor. This will cascade and delete the appointments
            // without deleting the detached medical records.
            doctorRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public List<Appointment> getAppointmentsByDoctorId(Long doctorId) {
        return appointmentRepository.findByDoctorId(doctorId);
    }
}
