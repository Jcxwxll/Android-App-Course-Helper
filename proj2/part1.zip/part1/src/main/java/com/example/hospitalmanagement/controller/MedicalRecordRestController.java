package com.example.hospitalmanagement.controller;

import com.example.hospitalmanagement.model.MedicalRecord;
import com.example.hospitalmanagement.service.MedicalRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;

@RestController
@RequestMapping("/medical-records")
public class MedicalRecordRestController {
    @Autowired
    private MedicalRecordService medicalRecordService;

    @PostMapping
    public ResponseEntity<MedicalRecord> createMedicalRecord(@Valid @RequestBody MedicalRecord record) {
        return new ResponseEntity<>(medicalRecordService.createMedicalRecord(record), HttpStatus.CREATED);
    }
}
